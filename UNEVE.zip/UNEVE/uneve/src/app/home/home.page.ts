import { Component } from '@angular/core';
import { IonButton, IonCheckbox, IonContent, IonIcon, IonInput, IonItem } from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  arrowForwardOutline,
  checkmarkCircleOutline,
  eyeOutline,
  lockClosedOutline,
  logInOutline,
  mailOutline,
  medkitOutline,
  personAddOutline,
  shieldCheckmarkOutline,
} from 'ionicons/icons';

type AuthMode = 'login' | 'register';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonButton, IonCheckbox, IonContent, IonIcon, IonInput, IonItem],
})
export class HomePage {
  mode: AuthMode = 'login';

  constructor() {
    addIcons({
      arrowForwardOutline,
      checkmarkCircleOutline,
      eyeOutline,
      lockClosedOutline,
      logInOutline,
      mailOutline,
      medkitOutline,
      personAddOutline,
      shieldCheckmarkOutline,
    });
  }

  setMode(mode: AuthMode): void {
    this.mode = mode;
  }
}
