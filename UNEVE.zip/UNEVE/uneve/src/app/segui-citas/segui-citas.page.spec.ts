import { TestBed } from '@angular/core/testing';
import type { ComponentFixture } from '@angular/core/testing';

import { SeguiCitasPage } from './segui-citas.page';

describe('SeguiCitasPage', () => {
  let component: SeguiCitasPage;
  let fixture: ComponentFixture<SeguiCitasPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SeguiCitasPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
