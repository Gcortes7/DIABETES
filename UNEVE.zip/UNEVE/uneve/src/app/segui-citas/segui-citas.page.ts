import { Component } from '@angular/core';
import {
  IonBadge,
  IonButton,
  IonCard,
  IonCheckbox,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonList,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTextarea,
  IonToolbar,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  addOutline,
  arrowBackOutline,
  calendarOutline,
  checkmarkOutline,
  closeOutline,
  documentTextOutline,
  eyeOutline,
  fileTrayOutline,
  logOutOutline,
  medicalOutline,
  personOutline,
  pulseOutline,
  settingsOutline,
  timeOutline,
} from 'ionicons/icons';

interface DocumentBlock {
  title: string;
  description: string;
  included: boolean;
}

@Component({
  selector: 'app-segui-citas',
  standalone: true,
  templateUrl: './segui-citas.page.html',
  styleUrls: ['./segui-citas.page.scss'],
  imports: [
    IonBadge,
    IonButton,
    IonCard,
    IonCheckbox,
    IonCol,
    IonContent,
    IonGrid,
    IonHeader,
    IonIcon,
    IonInput,
    IonItem,
    IonList,
    IonRow,
    IonSelect,
    IonSelectOption,
    IonTextarea,
    IonToolbar,
  ],
})
export class SeguiCitasPage {
  readonly blocks: DocumentBlock[] = [
    {
      title: 'Bloque 1: Identidad y Signos Vitales',
      description: 'Datos del paciente, signos vitales y antropometría.',
      included: true,
    },
    {
      title: 'Bloque 2: Metabólico / Diabetes',
      description: 'Omitido por información no aplicable a la paciente.',
      included: false,
    },
    {
      title: 'Bloque 3: Estructural y Pruebas Ortopédicas',
      description: 'Valoración quiropráctica y pruebas funcionales.',
      included: true,
    },
    {
      title: 'Bloque 4: Evolución y Tratamiento',
      description: 'Plan, seguimiento y próximas citas.',
      included: true,
    },
    {
      title: 'Bloque 5: Consentimientos y Documentos',
      description: 'Formatos y autorizaciones.',
      included: true,
    },
  ];

  constructor() {
    addIcons({
      addOutline,
      arrowBackOutline,
      calendarOutline,
      checkmarkOutline,
      closeOutline,
      documentTextOutline,
      eyeOutline,
      fileTrayOutline,
      logOutOutline,
      medicalOutline,
      personOutline,
      pulseOutline,
      settingsOutline,
      timeOutline,
    });
  }
}
