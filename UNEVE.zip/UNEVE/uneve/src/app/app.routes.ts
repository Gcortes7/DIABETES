import type { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.HomePage),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'segui-citas',
    loadComponent: () => import('./segui-citas/segui-citas.page').then((m) => m.SeguiCitasPage),
  },
];
